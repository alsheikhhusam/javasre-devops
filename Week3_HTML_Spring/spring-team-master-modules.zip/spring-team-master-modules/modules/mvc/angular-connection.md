# Using Angular to Connect to a Spring Endpoint

Connecting an Angular application to a Spring endpoint is nearly as simple as changing the URL in your service. The only snag is CORS. CORS stands for Cross Origin Resource Sharing, and it is used to restrict what entities are allowed to access resources belonging to other servers. Usually, when you run an Angular application, it is running on a different server than your Spring application. Most browsers will see this as an attempted attack and refuse the connection. To fix this, we must explicitly allow our resource to be accessed by our application, which we can do with the `@CrossOrigin` annotation in Spring.

Below find an example RestController. _Note the `@CrossOrigin` annotation._
```
@RestController
@RequestMapping(value="/cats")
@CrossOrigin
public CatController() {

    @Autowired
    private CatRepository cr;

    @GetMapping
    public ResponseEntity<List<Cat>> allcats() {
	    return ResponseEntity.status(HttpStatus.OK).body(cr.findAll());
    }
}
```

Below find a sample function using httpClient to access the endpoint. _Note that the URL used will depend on how you set up your Spring project._
```
getCats(): Observable<Cat[]> {
    return this.http.get<Cat[]>('http://localhost:8080/app/cats');
}
```