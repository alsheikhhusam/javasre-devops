package com.example.mymedia;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyMediaApplicationTests {

    @Test
    void contextLoads() {
    }

}
