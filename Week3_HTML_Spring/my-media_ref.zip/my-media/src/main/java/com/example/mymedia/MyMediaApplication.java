package com.example.mymedia;

import com.example.mymedia.dao.MmPostRepository;
import com.example.mymedia.dao.MmUserRepository;
import com.example.mymedia.models.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import javax.transaction.Transactional;
import java.util.*;

@SpringBootApplication
public class MyMediaApplication {

    @Autowired
    MmUserRepository userRepository;

    @Autowired
    MmPostRepository postRepository;

    public static void main(String[] args) {
        SpringApplication.run(MyMediaApplication.class, args);
    }

}
