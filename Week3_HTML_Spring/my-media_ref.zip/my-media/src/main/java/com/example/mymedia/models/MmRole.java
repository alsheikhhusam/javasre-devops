package com.example.mymedia.models;

public enum MmRole {
    ROLE_USER, ROLE_MANAGER, ROLE_ADMIN
}
