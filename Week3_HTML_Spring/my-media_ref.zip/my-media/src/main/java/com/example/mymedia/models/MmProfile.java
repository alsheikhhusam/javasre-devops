package com.example.mymedia.models;

import javax.persistence.*;

@Table(name = "mm_profile", indexes = {
        @Index(name = "mm_profile_email_key", columnList = "email", unique = true)
})
@Entity
public class MmProfile {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Integer id;

    @Column(name = "email", nullable = false, length = 40)
    private String email;

    public MmProfile() {
    }

    public MmProfile(Integer id, String email) {
        this.id = id;
        this.email = email;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }
}