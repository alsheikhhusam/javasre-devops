package com.example.mymedia.services;

import com.example.mymedia.dao.MmUserRepository;
import com.example.mymedia.dto.RegisterRequest;
import com.example.mymedia.models.MmProfile;
import com.example.mymedia.models.MmRole;
import com.example.mymedia.models.MmUser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class UserService {
    @Autowired
    PasswordEncoder encoder;

    @Autowired
    MmUserRepository userRepository;

    public MmUser registerUser(RegisterRequest registerRequest) {
        MmProfile profile = new MmProfile(0, registerRequest.getEmail());

        MmUser user = new MmUser(0, registerRequest.getUsername(), encoder.encode(registerRequest.getPassword()), MmRole.ROLE_USER, profile);

        return userRepository.save(user);

    }
}
