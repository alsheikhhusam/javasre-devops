## Infrastructure as Code Module

### References
References are resources (either external or internal) that trainers and associates can use to lookup information about the technology - typically documentation, notes, videos, or tutorials
* [AWS CloudFormation User Guide](https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/Welcome.html)
* [Terraform CLI Reference](https://www.terraform.io/docs/cli-index.html)

### Pre-Lecture Reading & Assignments
These are specific resources for associates to use BEFORE coming to lecture - could be tutorials, videos, etc
* [Terraform - Getting Started](https://learn.hashicorp.com/terraform/getting-started/install)

### List of Topics
These are links to the lecture notes and other resources for the topics in this module
* [Overview](./infrastructure-as-code-overview.md)
* [AWS CloudFormation](./aws-cloudformation.md)
* [Terraform](./terraform.md) - [Video Reference](https://www.youtube.com/watch?time_continue=4&v=h970ZBgKINg&feature=emb_logo)

### Prerequisites & Learning Objectives
* N/A

After completing all the modules in this repository, associates should be able to:
* Explain infrastructure as code as well as the benefits of adopting IaC tools
* Use an IaC tool to deploy simple cloud resources like virtual machines, cloud storage, and load balancers from a terminal

### Post-Lecture Assignments
* N/A
