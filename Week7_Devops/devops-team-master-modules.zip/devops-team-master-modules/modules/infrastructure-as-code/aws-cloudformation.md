# Infrastructure as Code - Amazon Web Service Cloud Formation

Amazon Web Services (AWS) Cloud Formation is a service which allows you to model AWS resources required to run applications which utilize AWS by creating templates to describe all AWS Resources needed.

### References
* [AWS Template Library](https://aws.amazon.com/cloudformation/resources/templates/)
* [AWS Resource and Property Types](https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-template-resource-type-ref.html)
* [AWS Resource Attribute Reference](https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-product-attribute-reference.html)

## Using AWS CloudFormation
AWS CloudFormation utilizes Templates and stacks to provision the resources for your application infrastructure.

### Important Terms
* Template
  * Blueprint used for building AWS resources.
  * Written as a JSON or YAML formatted text file, utilizing Key-value pairs.
  * Resources are described by their attributes and properties.
* Stack
  * Stacks are a grouping of all resources utilized to run a web application, for example, a web server, database, and the networking rules.
  * Created using an AWS CloudFormation Template and can be managed as a single unit.
  * Stacks can be created, updated, and deleted.
* Change Sets
  * A generated set of proposed changes on resources running in a stack.
  * Allows you to view the impact of changes before implementation (i.e. If you change the name of an RDS instance, it will create a new database and delete the old one, resulting in a loss of all non-backed up data).
* Resource
  * A configuration of an AWS Service described in a CloudFormation template.
  * AWS Templates require a Type attribute to be detailed for resources.
    * Type attributes have a specific format:
    * `AWS::ProductIdentifier::ResourceType`
    * For example:
    * `AWS::S3::Bucket` OR `AWS::EC2::Instance`
* Property
  * A type of attribute on a Resource that describes configuration for AWS resource instance.

Example (JSON):
```
{
  "AWSTemplateFormatVersion" : "2010-09-09",
  "Description" : "A simple EC2 instance",
  "Resources" : {
    "MyEC2Instance" : {
      "Type" : "AWS::EC2::Instance",
      "Properties" : {
        "ImageId" : "ami-0ff8a91507f77f867",
        "InstanceType" : "t1.micro"
      }
    }
  }
}
```

Example (YAML):
```
AWSTemplateFormatVersion: '2010-09-09'
Description: A simple EC2 instance
Resources:
  MyEC2Instance:
    Type: AWS::EC2::Instance
    Properties:
      ImageId: ami-0ff8a91507f77f867
      InstanceType: t1.micro
```
