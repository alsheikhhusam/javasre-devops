# Infrastructure as Code - Overview

An idempotent (inputs result in the same, expected output) method of managing software infrastructure.

### References
* [What is Infrastructure as Code? - Microsoft](https://docs.microsoft.com/en-us/azure/devops/learn/what-is-infrastructure-as-code)
* [What is Infrastructure as Code? - Stackifly](https://stackify.com/what-is-infrastructure-as-code-how-it-works-best-practices-tutorials/)
* [Infrastructure as Code - Wikipedia](https://en.wikipedia.org/wiki/Infrastructure_as_code)

## What is Infrastructure as Code?
Infrastructure as code (IaC) is the process of developing descriptive models of product infrastructure to maintain consistency between deployment environments. IaC utilizes the same versioning principles as DevOps teams for source code, and is key to achieving continuous delivery. This prevents environment drift during release cycles. Generally, IaC is achieved through one of two methods, either push or pull. IaC enables faster turn-around and testing in production environments for DevOps teams.

### Important Terms
* Idempotence
  * The idea that deployment commands utilizing IaC results in the same configuration for a target environment, regardless of that environment's starting state.
  * This can be achieved in 1 of 2 ways
    * Automatically updating the configuration of an existing environment
    * Discarding the existing environment and recreating a fresh one
* Push
  * The controlling server pushes configurations to the target system.
* Pull
  * The target system pulls configurations from the controlling server.

Advantages
* Speed
  * IaC allows for complete infrastructure setup by running a script.
* Consistency
  * Scripts allow for Idempotent configurations over multiple deployments.
* Lower Costs
  * Manual maintenance of environments is eliminated, so management of Infrastructure requires less professional and managerial staff.

 