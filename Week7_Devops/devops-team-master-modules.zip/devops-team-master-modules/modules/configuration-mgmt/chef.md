# Configuration Management - Chef

Chef is a company which provides a suite of automation tools and platforms allowing for the configuration and management of applications, servers and testing frameworks through the use of Chef code.

### References
* [Quick Start Guides](https://learn.chef.io/courses)
* [Habitat CLI Reference](https://www.habitat.sh/docs/habitat-cli/)
* [Habitat Builder - Community Package Repository](https://bldr.habitat.sh/#/pkgs/core)
* [Chef Infra - Resources](https://docs.chef.io/resources/)

## Overview:
Chef Offers various services and platforms to automate various enterprise programming tasks. 
* [Chef Habitat](https://www.habitat.sh/docs/) for application automation.
* [Chef Workstation](https://docs.chef.io/workstation/) for creating and administrating your infrastructure code.
* [Chef Infra](https://docs.chef.io/chef_overview/) for infrastructure automation.

## Chef Habitat
Chef Habitat is an open-source project which enables you to package your application's behavior with the configuration and management, allowing you to easily migrate  and deploy an application regardless of the environment.

This is accomplished by [Downloading and Installing Chef Habitat](https://www.habitat.sh/docs/install-habitat/), then creating packages using [Habitat Studio](https://www.habitat.sh/docs/glossary/#glossary-studio), a self-contained Linux environment, configured by the developer to only house the tools and dependencies as specified in each Chef Habitat package. This prevents unwanted dependencies from contaminating or interfering with your configuration in any way. These packages are then uploaded to Docker Containers as Images to be deployed on the intended environment.

Chef packages can be uploaded to, or obtained from Habitat Builder, a repository of Habitat Packages provided by the Habitat community.

### Important terms
* [Supervisor](https://www.habitat.sh/docs/glossary/#glossary-supervisor)
  * Process Manager used to run Habitat packages
  * Starts and monitors services defined in Habitat Package
  * Receives and acts upon configuration changes from other Supervisors

## Chef Workstation
Chef Workstation is a suite of testing tools (Cookstyle, Chef Spec, Chef InSpec and Test Kitchen), used to validate Chef Infra code before deployment to staging or production. Chef Workstation, and Chef Infra are driven by the concept of 'Resources', which are individual, configurable items on a server. These resources dictate what actions you want to perform. You can create your own, infrastructure specific resources for use in Chef Infra, however there are also a number of predefined resources for use in Chef Infra.

## Chef Infra
Chef Infra is a Ruby Based programming Language, used to write simple and descriptive commands to run on a server, for the purpose of automating the creation and management of infrastructure.

### Important terms
* Resource
  * A single configurable item
  * Resources act to provide content and context to a action you want to perform on a server
  * Resources require a name parameter and can have additional properties to describe additional information.
  * The structure of a Chef Command is as follows:
    * `chef-run <TARGET[S]> <RESOURCE> <RESOURCE_NAME> [PROPERTIES] [FLAGS]`
    * chef-run is a chef command
    * Target specifies what server to reference
    * Resource is the item you want to specify
    * Resource_name is the identifier for that resource
    * Properties are key-value pairs to provide additional information for a resource
    * Flags are additional meta-commands that can be run to provide information about a resource, provide configuration information and/or authentication
    * For Example:
```
chef-run web1 file hello.txt content='Hello World!'
```
    * This creates a file named hello.txt, in a server called "web1". The file will contain the text "Hello World"
* Recipe
  * Recipes are a group of Resources.
  * Distinguished with the '.rb' extension.
  * This allows for the configuration of multiple Resources
  * Additionally allows for easier reuse of code created
  * A limitation is that Recipes can get complex quickly if hard-coded content is utilized too much, or if a lot of content is required for a Resource within a recipe.
* Cook Book
  * A package of all recipe components
  * Cook books should always include a [metadata.rd](https://docs.chef.io/config_rb_metadata/) file which contains the name and version number of the cookbook and dependency information.
  * Cook books allow you to substitute data within a recipe with a reference to another recipe or file within the cookbook.

Example CookBook:
```
tree webserver
webserver/
|-- README.md
|-- metadata.rb
|-- recipes
|   `-- default.rb
`-- templates
    `-- index.html.erb
```
This cookbook contains 4 files (README.md, metadata.rb, default.rb and index.html.erb) and 2 directories (recipes and templates).

Using cat reveals the content within default.rb:
```
cat webserver/recipes/default.rb
 
#
# Cookbook:: webserver
# Recipe:: default
#
# Copyright:: 2018, The Authors, All Rights Reserved.
apt_update
 
package 'apache2'
 
template '/var/www/html/index.html' do
  source 'index.html.erb'
end
 
service 'apache2' do
  action [:enable, :start]
end
```
