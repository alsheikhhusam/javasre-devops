# Configuration Management - Salt

Infrastructure Management system built for data-driven orchestration of remotely executed infrastructure and configuration management.

### References
* [YMAL Reference](https://docs.saltstack.com/en/latest/topics/yaml/)
* [List of Terms](https://docs.saltstack.com/en/latest/glossary.html)

## Salt
Salt is a configuration management system, capable of maintaining remote nodes and their states. Additionally, Salt handles remote execution of a system by distributing commands and data queries on remote nodes, either individualls or based on arbitrary selection criteria.

### Important Terms
* Master
  * A central server which issues commands to listening minions
  * [Example Master Configuration File](https://docs.saltstack.com/en/master/ref/configuration/examples.html#example-master-configuration-file)
* Minion
  * A server running a Salt minion daemon, which listens for commands from a master and performs requested tasks.
  * [Example Minion Configuration File](https://docs.saltstack.com/en/master/ref/configuration/examples.html#example-minion-configuration-file)
* Grains
  * An interface to derive information about an underlying system.
  * Provide "Grains" of information to Salt
  * Consists of operating system, domain name, IP address, kernel, OS type, memory information and other system properties.
  * Utilizes key-value pairs
Grain Configuration (within minion configuration file):
```
#grains:
#  roles:
#    - webserver
#    - memcache
#  deployment: datacenter4
#  cabinet: 13
#  cab_u: 14-15
```
* Pillar
  * An interface which offers global values that may be distributed to minions
  * Stores values for user-defined data in key-value pairs.
  * Can be cached by master locally to bypass having to render pillars for each request made by a minion.
Pillar Configuration (within master configuration file)
Detailed notes can be found in the [master configuration file example](https://docs.saltstack.com/en/master/ref/configuration/examples.html#example-master-configuration-file).
```
#####         Pillar settings        #####
##########################################
pillar_roots:
  base:
    - /srv/pillar
ext_pillar:
  - hiera: /etc/hiera.yaml
  - cmd_yaml: cat /etc/salt/yaml
decrypt_pillar:
  - 'foo:bar': gpg
  - 'lorem:ipsum:dolor'
decrypt_pillar_delimiter: ':'
decrypt_pillar_default: gpg
  - gpg
ext_pillar_first: False
  - libvirt
  - virtkey
pillar_gitfs_ssl_verify: True
pillar_opts: False
pillar_safe_render_error: True
pillar_source_merging_strategy: smart
pillar_merge_lists: False
pillarenv_from_saltenv: False
pillar_raise_on_missing: False

# Git External Pillar (git_pillar) Configuration Options
#
git_pillar_provider: pygit2
git_pillar_base: master
git_pillar_branch: master
git_pillar_env: ''
git_pillar_root: ''
git_pillar_ssl_verify: False
git_pillar_global_lock: True

# Git External Pillar Authentication Options
#
git_pillar_user: ''
git_pillar_password: ''
git_pillar_insecure_auth: False
git_pillar_pubkey: ''
git_pillar_privkey: ''
git_pillar_passphrase: ''
git_pillar_refspecs:
  - '+refs/heads/*:refs/remotes/origin/*'
  - '+refs/tags/*:refs/tags/*'

pillar_cache: False
pillar_cache_ttl: 3600
pillar_cache_backend: disk

gpg_cache: False
gpg_cache_ttl: 86400
gpg_cache_backend: disk
```
* Target
  * The Minion(s) which will receive commands.

