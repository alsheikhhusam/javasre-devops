## Configuration Management Module

### References
* [Into to Configuration Management](https://www.digitalocean.com/community/tutorials/an-introduction-to-configuration-management)
* [What is Configuration Management and Why is it Important?](https://www.plutora.com/blog/configuration-management?utm_source=quora)
* [Ansible - Documentation](https://docs.ansible.com/ansible/latest/index.html)
* [Chef - Documentation](https://docs.chef.io/?_ga=2.252961487.752933650.1590784642-1898082282.1590784642)
* [Puppet - Documentation](https://puppet.com/docs/puppet/latest/puppet_index.html)
* [Salt - Documentation](https://docs.saltstack.com/en/latest/topics/states/)

### Pre-Lecture Reading & Assignments
These are specific resources for associates to use BEFORE coming to lecture - could be tutorials, videos, etc

### List of Topics
These are links to the lecture notes and other resources for the topics in this module
* [Overview of Configuration Management](./configuration-mgmt-overview.md)
* [Ansible](./ansible.md)
* [Chef](./chef.md)
* [Puppet](./puppet.md)
* [Salt](./salt.md)

### Prerequisites & Learning Objectives
* [Docker](https://gitlab.com/revature_training/docker-team)

After completing all the modules in this repository, associates should be able to:
* Explain the use of configuration management tools and the features they provide
* Use an open source configuration management tool to standardize and manage various deployment environments

### Post-Lecture Assignments
* N/A
