# Configuration Management - Ansible

Ansible is an IT automation and orchestration network, including a simple automation language, an automation engine and an enterprise framework, called Ansible Tower, used to manage the automation process with the use of a RESTful API. Ansible allows for the central node to remotely access other systems and perform tasks on those system automatically.

### References
* [Ansible Quick Start](https://www.ansible.com/resources/videos/quick-start-video?extIdCarryOver=true&sc_cid=701f2000001OH7YAAW)
* [Ansible User Guide](https://docs.ansible.com/ansible/latest/user_guide/index.html)

## Ansible
The ansible language is:
* Self-descriptive, making it easy for developers and non-developers to read code and understand at least the high-level processes
* Both human and machine readable
* YAML based

### Important Terms
* Playbook
  * Plain text file that describes the state of something
* Variable
  * Properties which allow you to alter how a playbook is run
* Inventory
  * The list of targets on which playbooks should be run (i.e. what do you want to run your automated tasks on)
* Play
  * A group of tasks
* Handler
  * An action run at the end of a play
* Task
  * A specific action to be run.
  * Tasks run sequentially (in the order you put them)
  * Can trigger Handlers
  * Self-documenting (the name of the task should be descriptive of what action it takes)

[Example Configuration - Github](https://github.com/ansible/ansible/blob/devel/examples/ansible.cfg) (Removed some comments for readability):
```
# Example config file for ansible -- https://ansible.com/
# =======================================================

# Nearly all parameters can be overridden in ansible-playbook
# or with command line flags. Ansible will read ANSIBLE_CONFIG,
# ansible.cfg in the current working directory, .ansible.cfg in
# the home directory, or /etc/ansible/ansible.cfg, whichever it
# finds first

# For a full list of available options, run ansible-config list or see the
# documentation: https://docs.ansible.com/ansible/latest/reference_appendices/config.html.

[defaults]
inventory       = /etc/ansible/hosts
library         = ~/.ansible/plugins/modules:/usr/share/ansible/plugins/modules
module_utils    = ~/.ansible/plugins/module_utils:/usr/share/ansible/plugins/module_utils
remote_tmp      = ~/.ansible/tmp
local_tmp       = ~/.ansible/tmp
forks           = 5
poll_interval   = 0.001
ask_pass        = False
transport       = smart

gathering = implicit
gather_subset = all
gather_timeout = 10
inject_facts_as_vars = True

collections_paths = ~/.ansible/collections:/usr/share/ansible/collections

roles_path = ~/.ansible/roles:/usr/share/ansible/roles:/etc/ansible/roles

host_key_checking = True

stdout_callback = yaml

callback_whitelist = timer, mail

task_includes_static = False
handler_includes_static = False

error_on_missing_handler = True

timeout = 10

remote_user = root

log_path = /var/log/ansible.log

module_name = command

executable = /bin/sh

private_role_vars = False

# List any Jinja2 extensions to enable here.
jinja2_extensions = jinja2.ext.do,jinja2.ext.i18n

private_key_file = /path/to/file
vault_password_file = /path/to/vault_password_file
ansible_managed = Ansible managed: {file} modified on %Y-%m-%d %H:%M:%S by {uid} on {host}
ansible_managed = Ansible managed
display_skipped_hosts = True
display_args_to_stdout = False
error_on_undefined_vars = False
system_warnings = True
deprecation_warnings = True
command_warnings = False


# set plugin path directories here, separate with colons
action_plugins     = /usr/share/ansible/plugins/action
become_plugins     = /usr/share/ansible/plugins/become
cache_plugins      = /usr/share/ansible/plugins/cache
callback_plugins   = /usr/share/ansible/plugins/callback
connection_plugins = /usr/share/ansible/plugins/connection
lookup_plugins     = /usr/share/ansible/plugins/lookup
inventory_plugins  = /usr/share/ansible/plugins/inventory
vars_plugins       = /usr/share/ansible/plugins/vars
filter_plugins     = /usr/share/ansible/plugins/filter
test_plugins       = /usr/share/ansible/plugins/test
terminal_plugins   = /usr/share/ansible/plugins/terminal
strategy_plugins   = /usr/share/ansible/plugins/strategy

strategy = linear
bin_ansible_callbacks = False

# set to 1 if you don't want cowsay support or export ANSIBLE_NOCOWS=1
#nocows = 1

cow_selection = default
# Alternative:
#cow_selection = random

# When using the 'random' option for cowsay, stencils will be restricted to this list.
# it should be formatted as a comma-separated list with no spaces between names.
# NOTE: line continuations here are for formatting purposes only, as the INI parser
#       in python does not support them.
#
#cow_whitelist=bud-frogs,bunny,cheese,daemon,default,dragon,elephant-in-snake,elephant,eyes,\
#              hellokitty,kitty,luke-koala,meow,milk,moofasa,moose,ren,sheep,small,stegosaurus,\
#              stimpy,supermilker,three-eyes,turkey,turtle,tux,udder,vader-koala,vader,www

# set to 1 if you don't want colors, or export ANSIBLE_NOCOLOR=1
nocolor = 1

fact_caching = memory
fact_caching_connection=/tmp

retry_files_enabled = True
retry_files_save_path = ~/.ansible-retry

no_log = False

no_target_syslog = False

allow_world_readable_tmpfiles = False

module_compression = 'ZIP_DEFLATED'

max_diff_size = 104448

show_custom_stats = False

inventory_ignore_extensions = ~, .orig, .bak, .ini, .cfg, .retry, .pyc, .pyo

network_group_modules=eos, nxos, ios, iosxr, junos, vyos

allow_unsafe_lookups = False

any_errors_fatal = False


[inventory]
enable_plugins = host_list, script, auto, yaml, ini, toml

ignore_extensions = .pyc, .pyo, .swp, .bak, ~, .rpm, .md, .txt, ~, .orig, .ini, .cfg, .retry

ignore_patterns=

unparsed_is_failed = False


[privilege_escalation]
become = False
become_method = sudo
become_ask_pass = False


## Connection Plugins ##

# Settings for each connection plugin go under a section titled '[[plugin_name]_connection]'
# To view available connection plugins, run ansible-doc -t connection -l
# To view available options for a connection plugin, run ansible-doc -t connection [plugin_name]
# https://docs.ansible.com/ansible/latest/plugins/connection.html

[paramiko_connection]
record_host_keys=False

pty = False
look_for_keys = False
host_key_auto_add = True


[ssh_connection]
# ssh arguments to use
# Leaving off ControlPersist will result in poor performance, so use
# paramiko on older platforms rather than removing it, -C controls compression use
#ssh_args = -C -o ControlMaster=auto -o ControlPersist=60s

control_path_dir = ~/.ansible/cp
control_path = %(directory)s/%%C

pipelining = False

scp_if_ssh = smart

transfer_method = smart

sftp_batch_mode = False

usetty = True

retries = 3


[persistent_connection]
# Configures the persistent connection timeout value in seconds. This value is
# how long the persistent connection will remain idle before it is destroyed.
# If the connection doesn't receive a request before the timeout value
# expires, the connection is shutdown. The default value is 30 seconds.
connect_timeout = 30

command_timeout = 30


## Become Plugins ##
# Settings for become plugins go under a section named '[[plugin_name]_become_plugin]'
# To view available become plugins, run ansible-doc -t become -l
# To view available options for a specific plugin, run ansible-doc -t become [plugin_name]
# https://docs.ansible.com/ansible/latest/plugins/become.html

[sudo_become_plugin]
flags = -H -S -n
user = root


[selinux]
# file systems that require special treatment when dealing with security context
# the default behaviour that copies the existing context or uses the user default
# needs to be changed to use the file system dependent context.
special_context_filesystems=fuse,nfs,vboxsf,ramfs,9p,vfat

# Set this to True to allow libvirt_lxc connections to work without SELinux.
libvirt_lxc_noseclabel = False

[colors]
highlight = white
verbose = blue
warn = bright purple
error = red
debug = dark gray
deprecate = purple
skip = cyan
unreachable = red
ok = green
changed = yellow
diff_add = green
diff_remove = red
diff_lines = cyan

[diff]
# Always print diff when running ( same as always running with -D/--diff )
#always = False

# Set how many context lines to show in diff
#context = 3
```
## Installation
Ansible only needs to be installed on a control node (the server used to manage your other technology assets). This control node will then use SSH (by default) to communicate between the other managed nodes (devices) as needed.

Step-by-step Installation can be found [here](https://docs.ansible.com/ansible/latest/installation_guide/intro_installation.html).
