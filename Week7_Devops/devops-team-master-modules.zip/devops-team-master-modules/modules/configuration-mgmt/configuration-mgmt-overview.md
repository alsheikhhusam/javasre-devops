# Configuration Management - Overview

Configuration management is a systematic process for managing and handling changes to the software and hardware assets of a company. Configuration Management tools, such as ansible, chef, salt and puppet ensure that the state of these assets match the states described by provisioning or management scripts.

## Benefits of Configuration Management
* Quick Provisioning
  * Provisioning, or the act of allocating more resources to a running application (such as the creation and deployment of a new server), can be automated using configuration management tools.
  * This can eliminate potential human error
  * Allows for tedious tasks to be performed faster and more accurately.
* Disaster Recovery
  * If critical events cause servers to stop functionality, you can quickly deploy replacement servers reliably.
  * Additionally, version control is maintained and server rollbacks are made available when needed
* Scalability
  * Managing the state of servers can allow for more reliable detection of resources and services, and allows for additional provisioning when needed.
  * Management also allows for easier communication and collaboration between teams, which can help scale project requirements.

## Configuration Management and Dev Ops
By definition, Configuration Management reflects the same underlying principle of Agile development, seeking to safely manage needed changes as quickly as possible. Technically speaking, the use of development pipelines to create artifacts can be seen as a form of configuration management.

## Configuration Management Tools
* [Ansible](./ansible.md)
* [Chef](./chef.md)
* [Puppet](./puppet.md)
* [Salt](./salt.md)