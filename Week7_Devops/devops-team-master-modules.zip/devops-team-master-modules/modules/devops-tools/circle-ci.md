# DevOps Tools - Circle CI

Circle CI is a development automation tool used to build, test and deploy software projects. Circle CI can integrate with a Docker environment with ease.

### References
* [Circle CI - Documentation](https://circleci.com/docs/)

## [Circle CI Installation](https://circleci.com/docs/2.0/first-steps/#section=getting-started)
To utilize Circle CI you must [sign up](https://circleci.com/signup/) for an account, and allow Circle CI access to your Github or Bitbucket repository.  Afterwards, you will gain access to the pipeline dashboard, which will allow you to begin building your project.

## Circle CI
Circle CI utilizes Projects, which share to name of the associated repository, to manage development Pipelines. Circle CI also employs [Orbs](https://circleci.com/docs/2.0/orb-intro/), a reusable snipper of code to help automate repeated processes, speed up setup, or allow for easier integration with third-party tools.

Orbs consist of:
* Jobs
  * Jobs consist of two distinct parts: The set of steps to execute and the environment in which they should be executed.
  * Jobs are defined in build configurations, or within an orb.
* Commands
  * Reusable sets of steps that can be invoked with specific parameters within a job
* Executors
  * A definition for the environment in which jobs are run. These configurations can also include parameters such as:
    * Environment variables to populate
    * Which shell to use
    * The resource_class size to use

### Disadvantages of Circle CI
* Job Limits with free account
* Free Option does not support Windows OS

### Advantages of Circle CI
* Includes a free plan
* Pre-built Circle CI docker Images are available
* Orbs can ease the burden of repeated tasks
