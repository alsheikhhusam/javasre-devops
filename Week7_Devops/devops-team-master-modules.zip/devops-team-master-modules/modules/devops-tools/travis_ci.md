# DevOps Tools - Travis CI

Travis CI is a hosted continuous integration service which can be used to build and test software projects using a Github or Bitbucket repository, allowing for immediate feedback and management of deployment and notifications.

### References
* [Travis CI - Documentation](https://docs.travis-ci.com/)
* [Job Lifecycle](https://docs.travis-ci.com/user/job-lifecycle/)

## Travis CI Installation
The steps [outlined here](https://docs.travis-ci.com/user/tutorial/#to-get-started-with-travis-ci-using-github) detail the integration of Travis CI with Github.

## Travis CI
Travis CI provides default configurations for the build environment and a default set of phases. These configurations are controlled via the `.travis.yml` file in your repository. This configuration file has [various configurations](https://config.travis-ci.com/) that allow for project specific jobs.

The tasks completed in the build are described within the `.travis.yml`. These tasks are detailed within their [Job Lifecycle](https://docs.travis-ci.com/user/job-lifecycle/), consisting of the installation of dependencies (if any), running build scripts, and option deployment phases.

Jobs are a sequence of phases, starting with an installation, followed by a script which is run. Additional, pre and post phases can be configured before or after both installation and/or scripts phases, as well as scripts triggered based on the success or failure of a script.

Jobs can also utilize a cache to store a file or directory of files, such as dependencies or source code. Each job can also detail specific requirements for each step when caching dependencies from previous jobs to clean up and speed up the build.

The deployment phase, made optional to allow for Continuous Deployment, like the others allows for configuration.

The complete sequence of phases of a job is the lifecycle. The steps are:

1. OPTIONAL `Install` apt addons
  * An optional step to install defined addons using apt (Advanced Packaing Tool)
1. OPTIONAL `Install` cache components
  * An optional step to cache certain component files. Increases efficiency if multiple same file is retrieved multiple times.
1. `before_install`
  * Steps taken before the main installation phase
1. `install`
  * Installation of any required dependencies
1. `before_script`
  * Steps taken before running the build script for job
1. `script`
  * Run the build script
1. OPTIONAL `before_cache`
  * If caching is used - setup for cleaning up cache
1. `after_success` or `after_failure`
  * Steps to take after script has resulted in success or failure
1. OPTIONAL `before_deploy`
  * Steps taken before deployment
  * Only occurs if deployment is active
1. OPTIONAL `deploy`
  * Deployment of build code
  * Only occurs if deployment is active
1. OPTIONAL `after_deploy`
  * Steps taken after deployment - i.e. cleanup
  * Only occurs if deployment is active
1. `after_script`
  * Steps taken after build script has finished

Note that a build may be composed of multiple jobs.

### Disadvantages of Travis CI
* No free solutions

### Advantages of Travis CI
* Supports macOS, Linux and Windows
* Some open source support for technology
* Provides default build configurations with yml file