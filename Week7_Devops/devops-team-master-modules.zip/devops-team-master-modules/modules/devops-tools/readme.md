## DevOps Tools Module

### References
* [Jenkins Reference](https://www.jenkins.io/doc/book/installing/)
* [SonarCloud Reference](https://sonarcloud.io/documentation)
* [SonarQube Reference](https://docs.sonarqube.org/latest/)
* [SonarLint Reference](https://www.sonarlint.org/features/)
* [Travis CI Reference](https://docs.travis-ci.com/)
* [Circle CI Reference](https://circleci.com/docs/)

### Pre-Lecture Reading & Assignments
These are specific resources for associates to use BEFORE coming to lecture - could be tutorials, videos, etc

### List of Topics
These are links to the lecture notes and other resources for the topics in this module
* [Jenkins](./jenkins.md) - [Video Reference](https://www.youtube.com/watch?v=LFDrDnKPOTg)
* [Sonar](./sonar.md)
* [TravisCI](./travis-ci.md)
* [CircleCI](./circle-ci.md)

### Prerequisites & Learning Objectives
* DevOps Concepts

After completing all the modules in this repository, associates should be able to:
* Setup a CI/CD pipeline for either continuous integration, delivery, or deployment using an open source CI tool
* Configure plugins for alerting about build failures
* Use Sonar reports to analyze code quality
* Integrate SonarCloud reports with a Jenkins pipeline

### Post-Lecture Assignments
* N/A
