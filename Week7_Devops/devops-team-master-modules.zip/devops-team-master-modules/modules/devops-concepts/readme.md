## Devops Concepts Module

### References
References are resources (either external or internal) that trainers and associates can use to lookup information about the technology - typically documentation, notes, videos, or tutorials
* [Martin Fowler - Software Delivery Guide](https://martinfowler.com/delivery.html)
* [Wikipedia - DevOps](https://en.wikipedia.org/wiki/DevOps#References)

### Pre-Lecture Reading & Assignments
These are specific resources for associates to use BEFORE coming to lecture - could be tutorials, videos, etc
* [Martin Fowler - DevOps Culture](https://martinfowler.com/bliki/DevOpsCulture.html)
* [Martin Fowler - Continuous Delivery](https://martinfowler.com/bliki/ContinuousDelivery.html)
* [Martin Fowler - Deployment Pipeline](https://martinfowler.com/bliki/DeploymentPipeline.html)

### List of Topics
These are links to the lecture notes and other resources for the topics in this module
* [DevOps Overview](./devops-overview.md)
* [Continuous Integration](./continuous-integration.md)
* [Continuous Delivery](./continuous-delivery.md) - [Video Reference](https://www.youtube.com/watch?v=aoMfbgF2D_4)
* [Continuous Deployment](./continuous-deployment.md)
* [DevOps and Agile](./devops-agile.md)

### Prerequisites & Learning Objectives
* N/A

After completing all the modules in this repository, associates should be able to:
* Explain the difference between continuous integration, continuous delivery, and continuous deployment
* Articulate the costs and benefits of adopting DevOps practices in a development team
* Explain the idea of a DevOps pipeline as well as general steps within a pipeline

### Post-Lecture Assignments
* N/A
