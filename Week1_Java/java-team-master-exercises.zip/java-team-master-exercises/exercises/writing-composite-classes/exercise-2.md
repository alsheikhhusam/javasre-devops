# Exercise Two

Add two constructors to WeatherMachine. One is the default no-arg constructor and the other should declare a String parameter called, city. Add a String instance variable that is updated with a default value or the one passed to the 2nd constructor.

Update the `getWeatherReport` method to print the name of the city along with the report.

When you are done, please Mark this activity Complete.