# Exercise Two

Implement binary search using recursion. You should search upon an int array and return the index of a given `int`. If the number is not in the list, then return -1;

> NOTE: You may create additional methods to help solve this one.