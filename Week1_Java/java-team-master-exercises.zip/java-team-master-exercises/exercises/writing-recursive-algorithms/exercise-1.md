# Exercise One

Write a recursive method to print itself and all previous letters of the alphabet given a single letter on the same line. You can assume the letter will be lowercase.

> HINT: Use the `char` data type as it is easy to convert one letter to the next using mathematical operators.