# Exercise 1

Create an array of ten `byte` values. The values can be any arbitrary numbers that you choose. Now use a `for` loop to iterate over the elements in the array and print them to the console. 

Please save your work and mark this activity complete.