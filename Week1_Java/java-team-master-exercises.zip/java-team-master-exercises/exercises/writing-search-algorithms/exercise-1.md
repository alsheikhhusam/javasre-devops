# Exercise One

Create a variation of the `findLetter` method that starts the search at the back of the dataset as opposed to the front. You may call the method `findLetterBackwards`.