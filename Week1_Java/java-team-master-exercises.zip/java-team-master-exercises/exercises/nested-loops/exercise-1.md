# Exercise 1

Now that we’ve walked you through an exercise, it’s time for you to try one on your own. You can check your work at the end with our posted solution in the Reference section.

For this exercise, we want you to create a Name Generator. We’ll stick to just first and last names. Your program should list all possible combinations between a first name and a last name from lists that are provided.

First Names:

*   Adam, Alexis, Dennis, Jose, Jessica, Meghan, Memphis, Nicky, Sarah, William
    

Last Names:

*   Adamson, Bond, Brown, Johnson, Gallagher, Smith, Thompson, Perez, Snow, Tran