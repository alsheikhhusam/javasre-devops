# Exercise 1

Create a method named `getPi` that returns the value of pi.

**HINT**: You can use the Math class to get the value of pi.

```java
double d = Math.PI;
```