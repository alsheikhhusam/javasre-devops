# Exercise 2

Write a method to return an array of characters that represent that letters from `a` to `z`. You can name the method `getAlphabetArray`.