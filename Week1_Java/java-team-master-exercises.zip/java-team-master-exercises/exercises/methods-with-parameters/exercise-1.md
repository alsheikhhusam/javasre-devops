**Exercise One**

Create a method that declares four int parameters, squares each, and places the results in a float array. The method should return the float array result. Name the method _square_.