**Exercise Two**

Create a method that declares two String parameters. This method should search through each parameter and determine the value that should come first if they were sorted alphabetically. Whichever value is first from both parameters should be returned. Name the method findFirstWord.

You can assume that both inputs are the same length and are actual words (not numbers). You can also assume that the length of each word will be at least 3 letters.