## Intro to Linux Module

### References
* [Treebeard's Unix Cheat Sheet](http://www.rain.org/~mkummel/unix.html)

### List of Topics
* [Unix/Linux introduction](./unix.md)
* [Basic Linux Commands](./commands.md)
* [Environment Variables](./environment.md)
* [Command-line Editors](./editors.md)
* [Package Managers](./package-managers.md)
* [File Permissions](./file-permissions.md)

### Prerequisites & Learning Objectives
* Basic understanding of file systems

After completing all the modules in this repository, associates should be able to:
* Navigate file systems using unix commands in a terminal
* Explain what Bash is
* List common unix commands and their usage
* Explain and modify unix file permissions
* Utilize a basic command-line file editor
* Explain and utilize a unix package manager

### Post-Lecture Assignments
TBD
