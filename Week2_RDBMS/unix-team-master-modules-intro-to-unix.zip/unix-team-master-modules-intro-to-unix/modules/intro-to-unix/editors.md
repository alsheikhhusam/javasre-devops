# Command-line Text Editors
You can write files in the shell by making use of built-in text editors such as `nano` and `vim` or `vi`.

## Guides
* [Beginner's Guide to Nano](https://www.howtogeek.com/howto/42980/the-beginners-guide-to-nano-the-linux-command-line-text-editor/)
* [Beginner's Guide to Vim](https://www.linux.com/training-tutorials/vim-101-beginners-guide-vim/)