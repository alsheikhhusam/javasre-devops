##  Module

The purpose of this module is 

Additional resources in this module:
* [Lecture notes](./lecture-notes.md)
* [Exercises](./exercises.md)

## List of Topics
* Background
* Data Types
* Conventions

## Prerequisites & Learning Objectives

Before starting with the material in this module, associates should be familiar with:
- N/A

After completing all the modules in this repository, associates should be able to:
- Explain what a database is
- Explain the differences between relational and nonrelational or NoSQL databases
- List different RDBMS vendors and some differences between them
- List several SQL data types commonly used
- Explain how SQL is used to interact with relational databases
