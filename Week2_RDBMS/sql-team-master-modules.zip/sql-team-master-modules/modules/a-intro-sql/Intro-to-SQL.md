## Intro to SQL

SQL stands for **Structured Query Language** - it is a domain-specific language for working with certain databases called relational databases. SQL is not a programming language, although there are extensions to the specification like PL/SQL that add familiar programming constructs. Instead, it is an English-like syntax that lets developers and database administrators abstract away the process of manipulating data and focus on the *WHAT* instead of *HOW* in the database.

Before we understand more about SQL, we need to understand what a relational database is. A relational database is a type of database that stores information in tables - that is, the data is stored in rows and columns, similar to a spreadsheet. Each row in the table is a record, and each record has properties which correspond to the different columns in the table. In order to provide a way for external entities to manipulate the database, we use a special kind of software called a relational database management system, or RDBMS. 

Relational databases are often contrasted with another category of databases - non-relational databases. We won't go into the details of non-relational databases here, but you should be aware that there are major differences. Nonrelational databases do not store data within tables that relate to each other, and thus do not use SQL to interact with the databse.

RDBMS systems are one of the key components of any enterprise application or system. Why is this the case? Think about it - data by itself doesn’t mean a lot or even have intrinsic value. A lot of data thrown in a bucket would it mean be meaningless unless some kind of processing and analysis was done on it. Related data is what provides meaning and organizes the structure of data. For example, “an employee is in one or more departments”. We might have one table to store employees and another to store departments, and then define some relationship between them.

Normally, relational databases are used in an OLTP (OnLine Transaction Processing) environment, which means that the idea of having related data is preferable in a very transactional system, and that are normally row-based.

For non-transactional environments, the counter part is OLAP (OnLine Analytic Processing) systems, which are normally columnar-based, which is faster for reading but slower for manipulation.