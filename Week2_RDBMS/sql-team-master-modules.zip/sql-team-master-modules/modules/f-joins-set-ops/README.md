##  Module

The purpose of this module is 

Additional resources in this module:
* [Lecture notes](./lecture-notes.md)
* [Exercises](./exercises.md)

## List of Topics

- Defining joins
- Join syntax
- Inner joins
- Full outer joins
- Left and right joins
- Self-joins
- Cross-joins
- Equi-joins and theta-joins
- Aliases
- Set operators: UNION, UNION ALL, INTERSECT

## Prerequisites & Learning Objectives

Before starting with the material in this module, associates should be familiar with:

- Modules A, B, and C

After completing all the topics in this module, associates should be able to:

- Explain how joins and set operators differ
- Use joins to appropriately query for data across multiple tables
- Combine joins with other SQL clauses for more advanced queries
