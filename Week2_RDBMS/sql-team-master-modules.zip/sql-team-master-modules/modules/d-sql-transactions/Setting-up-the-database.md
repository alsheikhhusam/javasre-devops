## Module - JDBC

This module covers JDBC, the Java Database Connectivity API.

### Helpful References
* [Oracle - Intro to JDBC](https://docs.oracle.com/javase/tutorial/jdbc/overview/index.html)
* [Oracle JDBC tutorial](https://docs.oracle.com/javase/tutorial/jdbc/basics/index.html)
* [SQL Fiddle](http://sqlfiddle.com/)

### Background

JDBC is a Java API consisting of interfaces that allows Java applications to interact with relational databases. It comes with the Java Standard Edition (SE), so there is no need to include any external dependencies to get started. JDBC allows developers to query and manipulate any database that provides a JDBC driver - including Oracle DB, MySQL, Postgres, SQLServer, and many more. 

Since JDBC is a collection of interfaces, the database providers must write the drivers which **implement** the JDBC interfaces.

## Connect to Database

To connect to a database the following elements are needed:

1. Use either of the folling to retrieve a Connection object:
  a. The `DriverManager` class, the implementation of the JDBC interfaces (OJDBC for Oracle) 
  b. The `DataSource` interface (preferred)
2. Username.
3. Password.
4. URL (the endpoint to the database) - this varies by database, common connection string formats are:
  a. MySQL: `jdbc:mysql://myhost:3306/`
  b. Oracle: `jdbc:oracle:thin:@//myhost:1521/servicename`
  c. SQLServer: `jdbc:sqlserver://myhost:1433`
  d. PostgreSQL: `jdbc:postgresql://myhost:5432/dbname`