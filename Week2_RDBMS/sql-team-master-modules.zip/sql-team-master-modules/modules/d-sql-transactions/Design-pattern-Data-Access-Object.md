## Data Access Object Pattern

One common design pattern regarding data access logic is the Data Access Object pattern - or DAO.

This pattern achieves **abstraction** of functionality to retrieve, manipulate, and delete data (CRUD operations)
away from the users of data objects by using *interfaces* which define the relevant methods.

For example, say we have a `Car` table in our database that stores information of cars we'd like to view and manipulate.
We want to be able to grab a car from the database, update its information, and even delete a car.

First, we create an interface that defines the functionality we desire:

```java
public interface CarDAO {
  Car getCarByVIN(String vin);
  List<Car> getAllCars();
  void updateCar(Car c);
  void deleteCar(Car c);
}
```

This interface has declared all of the functionality we need. Now, we can implement the interface by writing the persistence-layer logic
in a class that implements the interface:

```java
public class CarOracleDAO implements CarDAO {
  public Car getCarByVIN(String vin) {
    // some JDBC code here...
    return myCar;
  }
  public List<Car> getAllCars() {
    // etc...
  }
  public void updateCar(Car c) {
    // more JDBC code here...
  }
  public void deleteCar(Car c) {
    // and so on..
  }
}

The benefit of using an interface to define these data operations is that we **don't care which underlying implementation is being used** - all we care about are the methods defined in the interface. If we use a `CarDAO` whose implementation is `CarOracleDAO`, we can later on easily swap out something like `CarMySQLDAO` or even `CarFileIODAO` to persist our Cars to local files instead of a database.

```java
CarDAO cd = new CarOracleDAO(); // at any time we can change CarOracleDAO to another class which implements CarDAO and the rest of the code works fine
List<Car> allCars = cd.getAllCars();
for (Car c : allCars) {
  cd.deleteCar(c);
}
System.out.println("I have demolished all the cars!!!");
```

With this example, we can really see the benefit of **abstraction** and how the DAO design pattern achieves it.
 
