##  Module

The purpose of this module is 

Additional resources in this module:
* [Lecture notes](./lecture-notes.md)
* [Exercises](./exercises.md)

## List of Topics

- Defining transactions
- Atomicity
- Consistency
- Isolation
  - Isolation levels
- Durability

## Prerequisites & Learning Objectives

Before starting with the material in this module, associates should be familiar with:

- All prior SQL modules

After completing all the modules in this repository, associates should be able to:

- Explain and give examples of transactions that occur in an RDBMS system
- Explain each of the ACID properties
- Explain each of the isolation levels and which read phenomena they prevent
- Set the isolation level on their RDBMS
