## Using Simple and Prepared Statements

Next, we can use the `Connection` object to create `Statement`s:

```java
String username = "Sally";
String myQuery = "SELECT * FROM users WHERE username = " + username;
Statement stmt = con.createStatement(myQuery); // just a regular Statement - vulnerable

String safeSQL = "SELECT * FROM users WHERE username = ?";
PreparedStatement ps = con.prepareStatement(safeSQL); // prevents SQL injection 
ps.setString(1,"Sally");
```

Generally, you'll want to use `PreparedStatement`s to avoid the security flaw of SQL injection as shown above. You mark the parameters in the SQL with "?" and then
later call `.set[datatype]()` methods to set those values dynamically, passing in the (1-based) index of the parameter and the value to use. Using
`PreparedStatement`s like this means that the SQL code will be pre-compiled before sending it over to the database to be executed - meaning 
that SQL injection is not possible.

## Executing SQL and Retrieving Results

Once we've created whichever `Statement` we're using, we can then execute the SQL on the database and retrieve results via a `ResultSet`:

```java
ResultSet rs = ps.executeQuery(); // for DQL, returns a ResultSet

// if our SQL is a DML or DDL statement, we can use executeUpdate which returns the number of rows the update touched
int rowsAffected = ps.executeUpdate();

// or, we can use execute for any SQL statement which returns true if it successfully completed
boolean executed = ps.execute();
```
