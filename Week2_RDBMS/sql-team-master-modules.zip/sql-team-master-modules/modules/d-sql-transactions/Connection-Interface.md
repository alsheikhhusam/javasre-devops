## Connection Interface and Interfaces of JDBC

The main interfaces of JDBC are:
1. `Connection` - used to execute statements and get database information.
2. `Statement` - regular SQL statement which can be hard to manage because single quotes need to be provided for String values.
  a. SQL Injection can happen.
3. `PreparedStatement`, Java precompiled and controlled type of Statement that provides more readability, maintainability and security (no SQL injections).
  a. Values are inserted with indexes, starting from 1.
  b. E.g.: "INSERT INTO TABLE_NAME VALUES(?,?,NULL)"
    i.  statement.setInt(1, 35);
    ii. statement.setString (2, "Hello");
    iii. Yes, they start indexing from 1.
4. `CallableStatement` - used to call stored procedures. (E.g.: {call <procedure-name>[(<arg1>,<arg2>, ...)]}).
5. `ResultSet` - the interface for retrieving and manipulating data from an SQL query

### Retrieving the `Connection` Object

**NOTE: before JDBC 4.0 (with Java SE 6), the programmer must first load the Driver implementation manually:**

```java
Class.forName(oracle.jdbc.driver.OracleDriver);
```

Assuming you are working with a JDK 6 or above, we can skip the above step and simply retrieve the `Connection` object in one of two ways:

1. Via the DriverManager class

```java
Connection con = DriverManager.getConnection("jdbc:mysql://myhost:3306/","myusername", "mypassword");
```

2. Via the DataSource interface (preferred)

The specific vendor driver will have an implementation for the interface:

```
OracleDataSource ods = new OracleDataSource();

ods.setServerName("myhost");
ods.setServiceName("myservice");
ods.setDriverType("thin");
ods.setUser("myuser");
ods.setPassword("mypass");

Connection con = ods.getConnection();
```