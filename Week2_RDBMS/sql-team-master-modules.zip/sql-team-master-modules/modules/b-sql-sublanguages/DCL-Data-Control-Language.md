## DCL

Data Control Language statements are used to manage the security and control of database systems.

* GRANT, to grant any permissions to an existing user.
```sql
GRANT PERMISSION TO USERNAME
```

* REVOKE, to revoke any permissions of an existing user.
```sql
REVOKE PERMISSION TO USERNAME
```
