##  Module

The purpose of this module is 

Additional resources in this module:
* [Lecture notes](./lecture-notes.md)
* [Exercises](./exercises.md)

## List of Topics

- Data Definition Language: CREATE, ALTER, DELETE, TRUNCATE, RENAME
- Data Manipulation Language: SELECT, INSERT, UPDATE, DELETE
- Data Query Language: SELECT
- Data Control Language: GRANT, REVOKE
- Transaction Control Language: ROLLBACK, SAVEPOINT
- SQL clauses: WHERE, LIKE, HAVING, GROUP BY, ORDER BY
- Scalar and aggregate functions

## Prerequisites & Learning Objectives

Before starting with the material in this module, associates should be familiar with:

- Module A topics (Introduction to SQL & RDBMS)

After completing all the modules in this repository, associates should be able to:

- List and explain the purpose of the five SQL sublanguages
- Explain the purpose of each command in each sublanguage
- Create, modify, and delete tables
- Insert, update, and delete records in a table
- Query a table for data given arbitrary conditions
- Use the common string, numeric, and date scalar functions
- Use the MIN, MAX, and AVERAGE aggregate functions
- Use the GROUP BY operator to aggregate records
- Sort returned records of a query in a given order

