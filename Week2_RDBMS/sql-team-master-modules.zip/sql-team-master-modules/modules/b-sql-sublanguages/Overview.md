## Overview

All SQL statements are separated into different sub categories, also known as sub-languages. There are 5 sublanguages of SQL in total:

1. DDL - data definition language
2. DML - data manipulation language
3. DQL - data query language
4. DCL - data control language
5. TCL - transaction control language

We will also cover scalar and aggregate functions here, which related to database queries.