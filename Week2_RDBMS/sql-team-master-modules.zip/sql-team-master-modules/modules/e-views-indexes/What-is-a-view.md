## Views

[Views](https://en.wikipedia.org/wiki/View_(SQL)) are virtual tables - they are constructed from DQL queries and provide a window or "view" into the table. Views can be used to provide access to some portion of the data in a table but not all, which might be useful if the data is sensitive and needs to be kept private. Views are also used to abstract or hide complexity in the database - a view could be constructed with joins over multiple tables so that end users can query from denormalized tables easily. Users can query views just as if they were normal tables. Changes to the underlying table will be reflected in the view whenever it is queried next.

### Materialized Views

Materialized views were introduced by Oracle and give a static snapshot of the data at a given point in time.