## Creating Views

Create a view with the following syntax:

```
CREATE VIEW [viewname] AS [any DQL statement]
```

For example,

```
CREATE VIEW myview AS SELECT col1, col2 FROM mytable WHERE mycolumn > 12
```

Now, we can query from the view just as we would from a table:

```
SELECT * FROM myview WHERE mycolumn > 20
```