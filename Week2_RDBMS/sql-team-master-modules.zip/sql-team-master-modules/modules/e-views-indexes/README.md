##  Module

The purpose of this module is 

Additional resources in this module:
* [Lecture notes](./lecture-notes.md)
* [Exercises](./exercises.md)

## List of Topics

- Views
- Indexes

## Prerequisites & Learning Objectives

Before starting with the material in this module, associates should be familiar with:

- Modules A & B

After completing all the topics in this module, associates should be able to:

- Explain the purpose of views in a database
- Create, modify, and delete a view
- Explain common performance problems in RDBMS systems
- Explain how indexes can improve performance
- Explain when to use indexes
- Create an index on a specific column
- Explain the different types of indexes
