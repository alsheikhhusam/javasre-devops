## Types of Indexes

Indexes can be categorized into two types: clustered and non-clustered. Clustered indexes alter the order in which the records are physically stored on disk. Thus only one clustered index can be created on a given table. Non-clustered indexes specify a logical ordering of rows but do not affect the physical ordering, so there may be more than one non-clustered index in a table.

Additionally, there are further types of indexes:

* Bitmap
* Dense
* Sparse
* Reverse
* Primary
* Secondary

In-depth knowledge of indexes is not necessary for our training purposes, however.
