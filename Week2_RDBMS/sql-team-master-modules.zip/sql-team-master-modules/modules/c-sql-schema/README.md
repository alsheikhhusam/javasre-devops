##  Module

The purpose of this module is 

Additional resources in this module:
* [Lecture notes](./lecture-notes.md)
* [Exercises](./exercises.md)

## List of Topics

* Defining Schema
* Constraints
* Referential Integrity
* Multiplicity and table relationships
* Normalization
* Entity Relationship Diagrams (ERDs)

## Prerequisites & Learning Objectives

Before starting with the material in this module, associates should be familiar with:

- Module A topics (Introduction to SQL & RDBMS)

After completing all the modules in this repository, associates should be able to:

- Explain what a database schema is and how to visualize it
- Create primary keys and foreign keys
- Use constraints to enforce data integrity and consistency
- Explain the concept of referential integrity
- Explain up to the 3rd normal form of normalization and how to achieve each level
- Decompose a denormalized table into 3rd normal form
