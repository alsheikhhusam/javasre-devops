##  Module

The purpose of this module is 

Additional resources in this module:
* [Lecture notes](./lecture-notes.md)
* [Exercises](./exercises.md)

## List of Topics

- Stored Procedures 
- User-defined functions
- Cursors
- Triggers
- Sequences

## Prerequisites & Learning Objectives

Before starting with the material in this module, associates should be familiar with:

- All other SQL modules

After completing all the modules in this repository, associates should be able to:

- Create custom stored procedures and functions
- Create triggers to manipulate data before and after inserting, updating, or deleting records
- Define a sequence and query for its current value
- Explain the purpose and use cases of triggers
